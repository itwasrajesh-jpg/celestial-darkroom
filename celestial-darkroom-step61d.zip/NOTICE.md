# Celestial Darkroom — notices

*Formerly Latent.*

Copyright © 2026 Celestial (itwasrajesh-jpg).

Celestial Darkroom is free software, released under the GNU General Public License version 3
or (at your option) any later version. See LICENSE for the full terms.

## Required attribution

Under GPLv3 §7(b), the following notices must be preserved in any distribution of
this software or of a work derived from it, and shown to users in a place they
can reasonably find:

> **Spektrafilm for Android** by Akshay Sharma — https://github.com/thetechgeekko/Spektrafilm-android
>
> Film modeling powered by **spektrafilm** (Andrea Volpato) — https://github.com/andreavolpato/spektrafilm
>
> **Celestial Darkroom** — https://github.com/itwasrajesh-jpg/celestial-darkroom

All three appear in the app's About screen with clickable links.

## What is whose

**spektrafilm** (Andrea Volpato) is the research and the film science: the spectral
model, the measured film and paper profiles, the density curves, and the
negative → enlarger → print → scan chain. CC BY-SA 4.0 for the profile and LUT data.

**Spektrafilm for Android** (Akshay Sharma) is the C++/NDK port of that engine to
Android, checked bit-for-bit against the original. GPLv3.

**Celestial Darkroom** (Celestial; formerly Latent) is this application: the camera (viewfinder, all lenses, DNG
capture, burst alignment and stacking, exposure and focus controls), the develop
flow and the darkroom, the live film preview in the viewfinder, the colour-noise
cleanup, the Display P3 and Rec.709 output conversions, the film-to-paper pairing,
and the FFT implementation of the diffusion filter. GPLv3.

## Engine

The engine and RAW decoder are fetched at build time from a pinned commit of a
mirror of the Android port; they are not vendored into this repository. The pinned
commit is recorded in `.github/workflows/build.yml` and shown in the About screen.
Local changes to the engine are kept as patch files in this repository's
`engine-patches/` folder and applied at build time, so every change is public here.

## Other components

- **LibRaw** — RAW decoding. LGPL-2.1 / CDDL-1.0.
- **JTransforms** — the FFT used by the diffusion filter. BSD 2-clause.
- Film profiles and LUTs from spektrafilm — CC BY-SA 4.0. Any profile derived from
  them (for example a blended emulsion) is also CC BY-SA 4.0 and must not be named
  as a product of Kodak, Fujifilm, Leica or any other manufacturer.
- **Roboto** (Roboto 3 Classic, Light/Regular/Medium/Bold, `app/src/main/res/font/`) — the app's
  font, bundled so the app looks the same on every phone. Copyright 2011 The Roboto Project Authors,
  SIL Open Font License 1.1 (full text in `app/src/main/res/raw/roboto_ofl.txt`). The OFL allows
  bundling with software under any licence, including GPLv3; the fonts themselves stay OFL.

"Celestial Darkroom" and "Celestial" are names, not licensed code: GPLv3 covers the software,
not the naming of it.

## Depth model (downloaded on first use, not part of the app)

The depth model is **Depth Anything V2 Small** by Lihe Yang, Bingyi Kang, Zilong Huang, Zhen Zhao,
Xiaogang Xu, Jiashi Feng and Hengshuang Zhao — https://github.com/DepthAnything/Depth-Anything-V2 —
licensed under the Apache License 2.0 (the Small model only; the larger models are not used, as
they are licensed for non-commercial use). The ONNX export is by fabio-sim —
https://github.com/fabio-sim/Depth-Anything-ONNX — also Apache-2.0. For this app its weights are
stored at half size (computed at full precision) and it is hosted as a release asset of this
repository. Apache-2.0 is compatible with this app's GPLv3.

## Tap-to-select model (downloaded on first use, not part of the app)

Tap to select uses **MobileSAM** by Chaoning Zhang, Dongshen Han, Yu Qiao, Jung Uk Kim,
Sung-Ho Bae, Seungkyu Lee and Choong Seon Hong — https://github.com/ChaoningZhang/MobileSAM —
licensed under the Apache License 2.0. It builds on **Segment Anything** by Meta AI
(https://github.com/facebookresearch/segment-anything), also Apache-2.0. For this app it was
exported to ONNX from the published weights (encoder and decoder as two files), its weights stored
at half size (computed at full precision), and it is hosted as a release asset of this repository.
Apache-2.0 is compatible with this app's GPLv3.

Both models run with **ONNX Runtime** (Microsoft, MIT License) — https://github.com/microsoft/onnxruntime
